from . import cli


def main():
    cli.cli()


if __name__ == "__main__":
    main()
